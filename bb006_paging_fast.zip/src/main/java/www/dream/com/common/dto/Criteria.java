package www.dream.com.common.dto;

import lombok.Data;

// @보다 만들어진 생성자가 우선순위가 더 높아서 나중에 @로 만들어진 생성자는 만들어지지 않는다.
@Data
public class Criteria {
	
	private static final float PAGINATION_TOTAL = 10;
	private int pageNumber; // 현재 Page 번호
	private int amount; // Page당 보여줄 Data 건 수 10개로 할 거임
	
	private int startPage, endPage; // Web 하단에 출력되는 Page Num을 표시해주는 속성들을 만들어 낼 것
	private boolean prev, next; // Page를 앞,뒤로 가기 활성화
	
	private int total; // 전체 Data건 수
	
	public Criteria() { // Default 생성자도 만들어 줄 것
		this(1, 10, 2100); // page 1쪽에 10개씩
	}
	
	public Criteria(int pageNumber, int amount) { // Server로 들어가는 두 가지의 생성자를 만들어준다.
		this(pageNumber, amount, 2100);
	}
	
	
	public Criteria(int pageNumber, int amount, int total) { // 생성자도 만들어주고
		this.pageNumber = pageNumber;
		this.amount = amount;
		this.total = total;
		
		calc(); // calc라는 함수하나 만들어줄 것
	}
	
	private void calc() {
		endPage = (int) (Math.ceil(pageNumber / PAGINATION_TOTAL) * PAGINATION_TOTAL);
		startPage = endPage - (int) (PAGINATION_TOTAL - 1);
		int realEnd = (int) Math.ceil((float) total / amount);
		if (endPage > realEnd) {
			endPage = realEnd;
		}
		prev = startPage > 1;
		next = endPage < realEnd;
		
		}
	}

