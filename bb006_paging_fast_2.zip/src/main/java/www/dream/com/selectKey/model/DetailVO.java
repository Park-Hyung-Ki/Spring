package www.dream.com.selectKey.model;

import lombok.Data;
//ddl을 만들었기에 그에 따른 Java에 맞는 형식을 만들어 줘야한다.(기계적으로)

@Data
public class DetailVO {
	private int	id;					
	private String info;				

}
