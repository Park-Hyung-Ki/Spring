package www.dream.com.bulletinBoard.control;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import www.dream.com.bulletinBoard.model.BoardVO;
import www.dream.com.bulletinBoard.model.PostVO;
import www.dream.com.bulletinBoard.service.BoardService;
import www.dream.com.bulletinBoard.service.PostService;
import www.dream.com.party.model.Party;
import www.dream.com.party.model.User;

//Post에 관한 Controller Class를 만들어 낼것. 0524 과정
@Controller
@RequestMapping("/post/*")
public class PostController {
	@Autowired
	private PostService postService;
	
	@Autowired
	private BoardService boardService;
	
	/* 특정 게시판에 등록되어 있는 게시글을 목록으로 조회하기 P.212  void :/post/list.jsp로 변함*/
	@GetMapping(value="list") // LCRUD 에서 L:list
	public void listPost(@RequestParam("boardId") int boardId, Model model) {
		// Model 객체를 사용해서 jsp로 정보를 넘김
		model.addAttribute("listPost", postService.getList(boardId)); // boardId를 집어넣으면 목록 정보가 나오겠지
		model.addAttribute("boardId", boardId); 
		// 밑에 redirect할때 특정 게시판이 살아있어야 removePost 운용이 가능해진다.
		// boardId라는 속성값이 계속해서 따라다닌다. 막상 찾아보려고 하니, PostVO에는 정보값이 없고, readPost.jsp에도 값이 없다.
		// 그래서 목록조회를 할때 boardId를 넣어서 list.jsp에서 어떤 자리에서 boardId라는 정보를 넣어서 다음(readPost)으로 전달이 될 수 있게끔
		model.addAttribute("boardName", boardService.getBoard(boardId).getName());
		//Home 화면에서 board 공지사항으로 바로 가기 위한 하나의 방법. 경로를 만들어 주기위한 기능을 정의하는 것이다.
		
	}
	
	@GetMapping(value="readPost")
	public void findPostById(@RequestParam("boardId") int boardId, @RequestParam("postId") String id, Model model) {
		model.addAttribute("post", postService.findPostById(id));
		model.addAttribute("boardId",boardId);// 그래서 findPostById 함수에도 boardId를 하나더 추가 시켜 주자
		// 그렇게 해야 remove쪽으로 던져줄 값이 하나 생긴다.
	}
	
	@GetMapping(value="registerPost") // LCRUD 에서 Create 부분
	public void registerPost(@RequestParam("boardId") int boardId , Model model) {
		model.addAttribute("boardId", boardId);
	}
	
	@PostMapping(value="registerPost") // LCRUD 에서 Update 부분
	public String registerPost(@RequestParam("boardId") int boardId, PostVO newPost , RedirectAttributes rttr) {
		BoardVO board = new BoardVO(boardId);
		Party writer = new User("hong");
		newPost.setWriter(writer);
		postService.insert(board, newPost);
		
		// 신규 게시글이 만들어 질때 select key를 이용하여 id가 만들어진다. PostMapper.xml에 id = "insert" 부분
		rttr.addFlashAttribute("result", newPost.getId());
		
		return "redirect:/post/list?boardId=" + boardId; //Redirect때문에 필요하다 Return 값이
		
		// 새로운 글을 등록하였을때 저장이 되게끔
	}
	
	//RedirectAttributes를 이용한 삭제 방법(Post방식 이용) 0525 Start
	@PostMapping(value="removePost") // 재요청을 할때 다시 속성을 주는 것 LCRUD : Delete
	public String removePost(@RequestParam("boardId") int boardId,
			@RequestParam("postId") String id, RedirectAttributes rttr) {
		if (postService.deletePostById(id)) { // postService Class를 호출 해줘야 한다.
			rttr.addFlashAttribute("result", "삭제 성공");
		}
		return "redirect:/post/list?boardId=" + boardId;
		// 내가 어떤 정보가 필요한데, 그 정보의 출발점은 어디며, 연동계통은 어디이며 그 정보를 살려내어서 이곳(removePost)까지 받아낼 것
	}
}

// boardId가 들어 오면 model 값에 boardId를 담고, readPost할때, 다시금 boardId로 받을 수 있다.
// 그리고 boardId값을 하나 더 던져줄 거고. 받은 boardId값을 다시 던져줄때 redirect 할 수 있도록