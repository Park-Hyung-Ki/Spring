package www.dream.com.common.persistence;

public interface CommonMngVOMapper { // PartyMapper, CommongMngVO xml을 서로 연동시키기 위해서

}
